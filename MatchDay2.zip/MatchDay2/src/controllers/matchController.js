const fs = require('fs');
const path = require('path');
const matchesDataPath = path.join(__dirname, '../data/matches.json');

// Function to get all upcoming matches
exports.getUpcomingMatches = (req, res) => {
    fs.readFile(matchesDataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Error reading matches data' });
        }
        const matches = JSON.parse(data);
        res.status(200).json(matches);
    });
};