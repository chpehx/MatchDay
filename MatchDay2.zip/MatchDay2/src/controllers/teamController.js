const fs = require('fs');
const path = require('path');
const teamsDataPath = path.join(__dirname, '../data/teams.json');

// Get all favorite teams
exports.getFavoriteTeams = (req, res) => {
    fs.readFile(teamsDataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Error reading teams data' });
        }
        const teams = JSON.parse(data);
        res.json(teams);
    });
};

// Add a team to favorites
exports.addFavoriteTeam = (req, res) => {
    const newTeam = req.body;

    fs.readFile(teamsDataPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: 'Error reading teams data' });
        }
        const teams = JSON.parse(data);
        teams.push(newTeam);

        fs.writeFile(teamsDataPath, JSON.stringify(teams, null, 2), (err) => {
            if (err) {
                return res.status(500).json({ message: 'Error saving team data' });
            }
            res.status(201).json(newTeam);
        });
    });
};