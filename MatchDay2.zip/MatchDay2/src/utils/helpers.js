const fs = require('fs');

const readJSONFile = (filePath) => {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error reading file from disk: ${error}`);
        return null;
    }
};

const writeJSONFile = (filePath, data) => {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error(`Error writing file to disk: ${error}`);
    }
};

const generateUniqueId = () => {
    return '_' + Math.random().toString(36).substr(2, 9);
};

module.exports = {
    readJSONFile,
    writeJSONFile,
    generateUniqueId
};