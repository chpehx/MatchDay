const express = require('express');
const router = express.Router();
const teamController = require('../controllers/teamController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/favorites', authMiddleware.verifyToken, teamController.getFavoriteTeams);
router.post('/favorites', authMiddleware.verifyToken, teamController.addFavoriteTeam);

module.exports = router;