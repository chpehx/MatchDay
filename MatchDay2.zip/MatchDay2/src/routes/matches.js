const express = require('express');
const router = express.Router();
const matchController = require('../controllers/matchController');

// Route to fetch the list of upcoming matches
router.get('/', matchController.getUpcomingMatches);

module.exports = router;