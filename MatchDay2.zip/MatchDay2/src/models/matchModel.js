const fs = require('fs');
const path = require('path');

const matchesFilePath = path.join(__dirname, '../data/matches.json');

class MatchModel {
    static getAllMatches() {
        const matchesData = fs.readFileSync(matchesFilePath);
        return JSON.parse(matchesData);
    }

    static getMatchById(id) {
        const matches = this.getAllMatches();
        return matches.find(match => match.id === id);
    }

    static addMatch(match) {
        const matches = this.getAllMatches();
        matches.push(match);
        fs.writeFileSync(matchesFilePath, JSON.stringify(matches, null, 2));
    }

    static updateMatch(id, updatedMatch) {
        const matches = this.getAllMatches();
        const matchIndex = matches.findIndex(match => match.id === id);
        if (matchIndex !== -1) {
            matches[matchIndex] = { ...matches[matchIndex], ...updatedMatch };
            fs.writeFileSync(matchesFilePath, JSON.stringify(matches, null, 2));
        }
    }

    static deleteMatch(id) {
        let matches = this.getAllMatches();
        matches = matches.filter(match => match.id !== id);
        fs.writeFileSync(matchesFilePath, JSON.stringify(matches, null, 2));
    }
}

module.exports = MatchModel;