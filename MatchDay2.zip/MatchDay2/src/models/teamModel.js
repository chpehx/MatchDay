const fs = require('fs');
const path = require('path');

const teamsFilePath = path.join(__dirname, '../data/teams.json');

class TeamModel {
    static getAllTeams() {
        const teamsData = fs.readFileSync(teamsFilePath);
        return JSON.parse(teamsData);
    }

    static addTeam(team) {
        const teams = this.getAllTeams();
        teams.push(team);
        fs.writeFileSync(teamsFilePath, JSON.stringify(teams, null, 2));
    }

    static findTeamById(id) {
        const teams = this.getAllTeams();
        return teams.find(team => team.id === id);
    }
}

module.exports = TeamModel;