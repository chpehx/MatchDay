const express = require('express');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const matchRoutes = require('./routes/matches');
const teamRoutes = require('./routes/teams');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use('/api/auth', authRoutes);
app.use('/api/matches', matchRoutes);
app.use('/api/teams', teamRoutes);

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/../views/index.html');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});