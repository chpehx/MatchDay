const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const usersDataPath = path.join(__dirname, '../data/users.json');

const authMiddleware = (req, res, next) => {
    const token = req.headers['authorization'];

    if (!token) {
        return res.status(403).json({ message: 'No token provided.' });
    }

    jwt.verify(token, 'your_secret_key', (err, decoded) => {
        if (err) {
            return res.status(401).json({ message: 'Unauthorized!' });
        }

        fs.readFile(usersDataPath, 'utf8', (err, data) => {
            if (err) {
                return res.status(500).json({ message: 'Error reading user data.' });
            }

            const users = JSON.parse(data);
            const user = users.find(user => user.id === decoded.id);

            if (!user) {
                return res.status(404).json({ message: 'User not found.' });
            }

            req.user = user;
            next();
        });
    });
};

module.exports = authMiddleware;